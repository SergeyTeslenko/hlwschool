const WIDTH = 480;
const HEIGHT = 360;

// create SVG document and set its size
let draw = SVG('game').size(WIDTH, HEIGHT);

let background = draw.rect(WIDTH, HEIGHT).fill('#dde3e1');

  
  

